const express = require('express')
const router = express.Router()
const pool = require('../queries')

router.get('/', (req, res)=>{
    const sql = 'SELECT * FROM film'
    pool.query(sql, (error, result)=>{
        if(erorr) throw eror
        res.send(result.rows)
    })
})

router.get('/listFilm/:id', (req, res)=>{
    const film_id = req.params.id
    const sql = 'SELECT * FROM film WHERE film_id=$1'
    pool.query(sql, [film_id], (erorr, result)=>{
        if(erorr) throw erorr
        res.send(result.rows).status(200)
    })
})

module.exports = router