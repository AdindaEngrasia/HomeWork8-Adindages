const express = require('express')
const app = express()
const port = 3001
const film = require('./models/film')
const listCategory = require('./models/listCategory')
const actor = require('./models/actor')


app.use('/film', film)

app.use(film)

app.use('/listCategory', listCategory)

app.use('/actor', actor)

app.listen(port, () => {
    console.log(`Server run in`)
})