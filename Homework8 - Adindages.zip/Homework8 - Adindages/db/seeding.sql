INSERT INTO actor (actor_id, first_name, last_name)
values  (201, 'Cillian', 'Murphy'),
        (202, 'Tom', 'Holland'),
        (203, 'Emma', 'Stone'),
        (204, 'Scarlett', 'Johansson'),
        (205, 'Chris', 'Evans')